public class A {

    private int e = 1;

    private double b = 100.500;

    public void aa() {
        return;
    }

    public void ab() {
        System.out.println();
    }
}
