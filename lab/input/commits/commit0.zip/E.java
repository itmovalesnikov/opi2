public class E implements G {

    private long h = 1234;

    private byte g = 1;

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }

    public String nn() {
        return "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++";
    }

    public int cc() {
        return 13;
    }

    public float ff() {
        return 0;
    }
}
