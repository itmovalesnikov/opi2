public class E implements G {

    private long h = 1234;

    private byte g = 1;

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }

    public String nn() {
        return "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++";
    }

    public int cc() {
        return 13;
    }

    public float ff() {
        return 0;
    }

    public void bb() {
        System.out.println(getClass().getName());
    }

    public int ae() {
        return 9;
    }

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }

    public int hh() {
        return new java.util.Random(10).nextInt(10);
    }
}
