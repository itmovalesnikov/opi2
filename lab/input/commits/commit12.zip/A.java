public class A extends null {

    private int e = 1;

    private double b = 100.500;

    public void aa() {
        return;
    }

    public void ab() {
        System.out.println();
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public long dd() {
        return 100500;
    }

    public double ad() {
        return 11;
    }

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }

    public Object pp() {
        return this;
    }

    public byte oo() {
        return 3;
    }

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }
}
