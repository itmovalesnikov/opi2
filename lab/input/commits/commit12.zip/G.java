public class G extends null {

    int cc();

    float ff();
}
