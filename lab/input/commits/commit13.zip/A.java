public class A extends null {

    private int e = 1;

    private double b = 100.500;

    public void aa() {
        return;
    }

    public void ab() {
        System.out.println();
    }

    public double ad() {
        return 9.11;
    }

    public long dd() {
        return 100500;
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public int af() {
        return -1;
    }

    public Object pp() {
        return this;
    }

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }

    public byte oo() {
        return 2;
    }

    public void bb() {
        System.out.println(42);
    }
}
