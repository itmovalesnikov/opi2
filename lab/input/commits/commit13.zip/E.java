public class E extends null implements G {

    private long h = 1234;

    private byte g = 1;

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }

    public String nn() {
        return "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++";
    }

    public int cc() {
        return 13;
    }

    public float ff() {
        return 0;
    }

    public void bb() {
        System.out.println(getClass().getName());
    }

    public int ae() {
        return 9;
    }

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }

    public int hh() {
        return new java.util.Random(10).nextInt(10);
    }

    public int af() {
        return -1;
    }

    public double ad() {
        return java.lang.Math.sqrt(13);
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public void ab() {
        return;
    }

    public Object pp() {
        return this;
    }
}
