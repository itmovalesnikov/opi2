public class B extends null {

    java.util.List<String> jj();

    int af();

    public double ee() {
        return 100.500;
    }
}
