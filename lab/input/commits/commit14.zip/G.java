public class G extends null {

    int cc();

    float ff();

    public java.lang.Class qq() {
        return getClass();
    }
}
