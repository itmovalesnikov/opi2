public interface B {

    java.util.List<String> jj();

    int af();
}
