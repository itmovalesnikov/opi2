public interface G {

    int cc();

    float ff();
}
