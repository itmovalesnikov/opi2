public class A {

    private int e = 1;

    private double b = 100.500;

    public void aa() {
        return;
    }

    public void ab() {
        System.out.println();
    }

    public long dd() {
        return 100500;
    }

    public double ad() {
        return 11;
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }
}
